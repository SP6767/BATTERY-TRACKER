# Battery Tracker (Android / ColorOS)

A native Kotlin Android project with a pure-black, white-text interface. The project is configured for Android 17 (API 37), with a minimum Android version of 8.0 (API 26).

## Included

- Separate charging and discharging event logs, timestamped whenever the app receives a battery percentage change broadcast.
- Screen-on duration accumulated from the most recently observed unplug event; charging time is excluded and the counter resets on unplug.
- Total charging duration across recorded charging sessions.
- Local SQLite storage; no INTERNET permission, analytics SDK, or cloud account.
- A low-importance foreground notification while tracking is active, to reduce the chance Android stops the event listener.
- Shortcut to ColorOS' own Battery Usage screen.

## Important limitation: per-app battery mAh / %

The app deliberately does **not** fabricate per-app battery consumption. Android's public `UsageStatsManager` API reports app foreground usage, not actual battery mAh. Detailed BatteryStats access is protected by privileged/signature permissions on production Android builds. OPPO documents its own ColorOS Battery Usage by App screen, but does not document a public third-party API for reading those per-app energy values. On an ordinary, non-rooted phone, this app therefore links to the ColorOS battery screen instead of presenting made-up values.

References:
- Android BatteryStats documentation: https://android.googlesource.com/platform/docs/source.android.com/+/26a6e1b2badf69ddc616ec51687c1d3ecfd8b646/en/devices/tech/power/batterystats.html
- Android UsageStatsManager: https://android.googlesource.com/platform/frameworks/base/+/HEAD/core/java/android/app/usage/UsageStatsManager.java
- OPPO Battery Usage by App: https://support.oppo.com/en/answer/?aid=2171043

## Build an APK

1. Open this folder in Android Studio with Android SDK Platform 37 installed.
2. Allow Gradle to sync (the project uses Android Gradle Plugin 8.13.2, Kotlin 2.2.20, and AndroidX Core 1.17.0).
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.
5. Install it on the phone and open Battery Tracker. Keep its tracking notification enabled.

## ColorOS setup

ColorOS may stop background apps aggressively. For more reliable event logging, allow Battery Tracker to auto-launch / run in the background and do not force-stop it. These settings can vary by OPPO/OnePlus model and ColorOS build. Reopen the app after a reboot to resume tracking.

## Accuracy notes

- Android broadcasts battery-level changes while the process is alive. If ColorOS force-stops the service, some percentage transitions can be missed.
- The timestamp is the time the app received the broadcast, not a hardware-measured instant.
- Screen-on time starts from the last unplug event observed by this app. It cannot reconstruct screen time from before the app was first installed or before tracking was started.
- The app stores local data only. Uninstalling it removes its database.
