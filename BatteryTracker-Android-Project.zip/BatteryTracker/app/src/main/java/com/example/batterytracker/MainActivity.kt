package com.example.batterytracker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tracking", MODE_PRIVATE) }
    private val store by lazy { Store(this) }
    private lateinit var body: LinearLayout
    private val white = 0xFFFFFFFF.toInt()
    private val grey = 0xFFAAAAAA.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF000000.toInt()
        window.navigationBarColor = 0xFF000000.toInt()
        startTracking()
        render()
    }
    override fun onResume() { super.onResume(); if (::body.isInitialized) render() }

    private fun startTracking() {
        val i = Intent(this, TrackingService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF000000.toInt()); setPadding(20, 20, 20, 16) }
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val level = currentBatteryLevel()
        addText("BATTERY TRACKER", 14, grey, true)
        addText("$level%", 42, white, true)
        addText("CURRENT BATTERY", 11, grey)
        addGap(20)
        val since = screenSinceUnplugMs()
        val charging = prefs.getLong("total_charge_ms", 0L) + currentChargeMs()
        addText("SCREEN-ON SINCE LAST UNPLUG", 11, grey)
        addText(formatDuration(since), 26, white, true)
        addGap(12)
        addText("TOTAL RECORDED CHARGING TIME", 11, grey)
        addText(formatDuration(charging), 24, white, true)
        addGap(20)
        addText("BATTERY EVENTS", 16, white, true)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val charge = Button(this).apply { text = "CHARGING"; setOnClickListener { showLog("charging") } }
        val discharge = Button(this).apply { text = "DISCHARGING"; setOnClickListener { showLog("discharging") } }
        tabs.addView(charge, LinearLayout.LayoutParams(0, -2, 1f)); tabs.addView(discharge, LinearLayout.LayoutParams(0, -2, 1f)); body.addView(tabs)
        addText("Latest charging events", 12, grey)
        store.recent("charging", 4).forEach { addText("${time(it.time)}     ${it.level}%", 14, white) }
        addText("Latest discharging events", 12, grey)
        store.recent("discharging", 4).forEach { addText("${time(it.time)}     ${it.level}%", 14, white) }
        addGap(18)
        addText("APP BATTERY CONSUMPTION / HOUR", 16, white, true)
        addText("Actual per-app mAh or % is not exposed to ordinary third-party apps through the public Android API. ColorOS calculates this internally, but OPPO does not provide a supported public API for exporting those per-app values. This section will not invent estimates.", 13, grey)
        addGap(8)
        val usageButton = Button(this).apply { text = "VIEW APP BATTERY USAGE IN COLOROS"; setOnClickListener { openOemBatteryUsage() } }
        body.addView(usageButton)
        addText("App foreground time by hour can be shown separately, but it is not battery consumption.", 12, grey)
        addGap(14)
        addText("TRACKING STATUS", 16, white, true)
        addText("Event tracking runs locally. A small persistent notification is used so Android is less likely to stop the battery event listener. No network access or analytics are used.", 12, grey)
    }

    private fun addText(value: String, size: Int, color: Int, bold: Boolean = false) {
        body.addView(TextView(this).apply { text = value; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 5, 0, 5) })
    }
    private fun addGap(dp: Int) { body.addView(View(this), LinearLayout.LayoutParams(1, dp)) }
    private fun showLog(kind: String) {
        val events = store.recent(kind, 200)
        val message = if (events.isEmpty()) "No $kind events recorded yet." else events.joinToString("\n") { "${time(it.time)}    ${it.level}%" }
        android.app.AlertDialog.Builder(this).setTitle(if (kind == "charging") "Charging log" else "Discharging log").setMessage(message).setPositiveButton("Close", null).show()
    }
    private fun currentBatteryLevel(): Int {
        val i = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    }
    private fun screenSinceUnplugMs(): Long {
        val base = prefs.getLong("screen_since_unplug", 0L)
        val start = prefs.getLong("screen_started", 0L)
        return base + if (start > 0L && !prefs.getBoolean("plugged", false)) (System.currentTimeMillis() - start).coerceAtLeast(0L) else 0L
    }
    private fun currentChargeMs(): Long {
        val start = prefs.getLong("charge_started", 0L)
        return if (prefs.getBoolean("plugged", false) && start > 0L) (System.currentTimeMillis() - start).coerceAtLeast(0L) else 0L
    }
    private fun formatDuration(ms: Long): String {
        val total = ms / 60000L; return "${total / 60}h ${total % 60}m"
    }
    private fun time(ms: Long) = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date(ms))
    private fun openOemBatteryUsage() {
        val i = Intent("android.intent.action.POWER_USAGE_SUMMARY")
        try { startActivity(i) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
}
