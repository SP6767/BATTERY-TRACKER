package com.example.batterytracker

import android.app.*
import android.content.*
import android.os.*
import androidx.core.app.NotificationCompat

class TrackingService : Service() {
    private val prefs by lazy { getSharedPreferences("tracking", MODE_PRIVATE) }
    private lateinit var store: Store
    private var lastLevel = -1
    private var plugged = false
    private var screenOn = false
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> handleBattery(intent)
                Intent.ACTION_SCREEN_ON -> { screenOn = true; prefs.edit().putLong("screen_started", System.currentTimeMillis()).apply() }
                Intent.ACTION_SCREEN_OFF -> closeScreenInterval()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        lastLevel = prefs.getInt("last_level", -1)
        plugged = prefs.getBoolean("plugged", false)
        createChannel()
        startForeground(7, notification())
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(receiver, filter)
        screenOn = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
        if (screenOn && !plugged) prefs.edit().putLong("screen_started", System.currentTimeMillis()).apply()
    }

    private fun handleBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val nowPlugged = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val now = System.currentTimeMillis()
        if (lastLevel < 0) {
            plugged = nowPlugged
            if (nowPlugged && prefs.getLong("charge_started", 0L) == 0L) prefs.edit().putLong("charge_started", now).apply()
            if (!nowPlugged) {
                prefs.edit().putLong("last_unplugged", now).apply()
                if (screenOn) prefs.edit().putLong("screen_started", now).apply()
            }
        }
        if (level >= 0 && lastLevel >= 0 && level != lastLevel) {
            store.add(if (level > lastLevel) "charging" else "discharging", level, now)
        }
        if (nowPlugged != plugged) {
            if (nowPlugged) {
                closeScreenInterval(markOff = false)
                prefs.edit().putLong("charge_started", now).apply()
            } else {
                val chargeStart = prefs.getLong("charge_started", 0L)
                if (chargeStart > 0L) prefs.edit().putLong("total_charge_ms", prefs.getLong("total_charge_ms", 0L) + (now - chargeStart).coerceAtLeast(0L)).apply()
                prefs.edit().putLong("charge_started", 0L).putLong("last_unplugged", now).putLong("screen_since_unplug", 0L).apply()
                if (screenOn) prefs.edit().putLong("screen_started", now).apply()
            }
            plugged = nowPlugged
        }
        lastLevel = level
        prefs.edit().putInt("last_level", level).putBoolean("plugged", plugged).apply()
    }

    private fun closeScreenInterval(markOff: Boolean = true) {
        val started = prefs.getLong("screen_started", 0L)
        if (started > 0L) {
            val add = (System.currentTimeMillis() - started).coerceAtLeast(0L)
            prefs.edit().putLong("screen_since_unplug", prefs.getLong("screen_since_unplug", 0L) + add).putLong("screen_started", 0L).apply()
        }
        if (markOff) screenOn = false
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("tracker", "Battery tracking", NotificationManager.IMPORTANCE_MIN).apply { description = "Low-overhead event logging" })
        }
    }
    private fun notification() = NotificationCompat.Builder(this, "tracker")
        .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
        .setContentTitle("Battery Tracker is recording")
        .setContentText("Logging battery level and screen state changes")
        .setOngoing(true).setSilent(true).build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?) = null
    override fun onDestroy() { try { unregisterReceiver(receiver) } catch (_: Exception) {}; super.onDestroy() }
}
