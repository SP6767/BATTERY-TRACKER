package com.example.batterytracker

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class BatteryEvent(val time: Long, val level: Int)

class Store(context: Context) : SQLiteOpenHelper(context, "battery_tracker.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY, kind TEXT NOT NULL, level INTEGER NOT NULL, at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(kind: String, level: Int, at: Long) {
        writableDatabase.execSQL("INSERT INTO events(kind,level,at) VALUES(?,?,?)", arrayOf(kind, level, at))
    }
    fun recent(kind: String, limit: Int = 80): List<BatteryEvent> {
        val out = mutableListOf<BatteryEvent>()
        readableDatabase.rawQuery("SELECT at,level FROM events WHERE kind=? ORDER BY at DESC LIMIT ?", arrayOf(kind, limit.toString())).use { c ->
            while (c.moveToNext()) out += BatteryEvent(c.getLong(0), c.getInt(1))
        }
        return out
    }
}
