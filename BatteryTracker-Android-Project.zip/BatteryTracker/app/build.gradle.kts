plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.batterytracker"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.example.batterytracker"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
    }
}


dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
}
