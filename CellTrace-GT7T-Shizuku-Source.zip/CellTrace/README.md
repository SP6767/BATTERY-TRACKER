# CellTrace — native battery history for realme GT 7T

CellTrace is a Kotlin/Jetpack Compose Android Studio starter project. It is designed for ColorOS 17 / Android 17 on the realme GT 7T, but the current source targets Android API 35 and compiles against API 36 so it can also be opened and tested on recent Android versions.

## Included in this source release

- Room database for timestamped battery-level transitions.
- Charging/discharging direction, temperature and voltage when Android reports them.
- Optional user-enabled foreground service with an ongoing notification.
- Optional restart after reboot when monitoring was enabled.
- Usage Access screen-interactive event calculation and per-package foreground activity totals.
- Shizuku API dependency and permission/status probe.
- Dark Compose dashboard and recent battery timeline.

## Important accuracy notes

1. `ACTION_BATTERY_CHANGED` is a sticky, dynamically registered broadcast. Android reports integer battery levels, but if the process is stopped or the OS skips an intermediate level, the app cannot know the exact crossing time. The logger records every crossed integer level; skipped steps are marked `INFERRED` and share the observation timestamp.
2. Screen-on time is computed from `SCREEN_INTERACTIVE` / `SCREEN_NON_INTERACTIVE` usage events. Grant Usage Access in Android Settings. The dashboard displays both since-last-charge and since-last-100% counters. UsageEvents are retained by Android for only a limited period (typically a few days), so long-running counters need a future persistent screen-event journal to remain complete across longer cycles.
3. Usage Access reports foreground activity time. It does **not** provide trustworthy per-app battery percentages or exact background CPU residency. Do not interpret foreground time as battery drain.
4. Per-app battery percentage per hour is not implemented in this starter release. Android's power attribution is device/build dependent. The Shizuku bridge currently checks availability and permission but deliberately does not invent percentages from raw `dumpsys batterystats` output. A follow-up device-specific parser should be validated against the GT 7T's ColorOS 17 build.
5. ColorOS may aggressively stop background services. Set CellTrace battery usage to Unrestricted / allow background activity if you want continuous logging. Monitoring remains opt-in and visible through a persistent notification.

## Build

1. Install Android Studio with JDK 17 and Android SDK Platform 36.
2. Open this folder as a project.
3. Allow Gradle sync to download dependencies.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the debug APK on the realme GT 7T.

The project is source code only; no APK is included.

## First-run setup on the phone

1. Open CellTrace.
2. Enable **Live battery logger** and allow notifications if requested.
3. Grant **Usage Access** from the button in the Screen Time section.
4. In ColorOS app battery settings, allow background activity / unrestricted battery use if continuous logging is desired.
5. Optional: install and start Shizuku, then use Check Shizuku. This release only verifies the bridge; it does not yet expose parsed per-app power percentages.

## Next engineering milestone

- Add a session table and separate SOT since most recent charge start and since last 100% full event.
- Add a validated parser for GT 7T BatteryStats UID data through Shizuku.
- Add hourly app drain estimates only where system power attribution supplies defensible values; otherwise show foreground/background activity durations separately.
- Add export to CSV and retention controls.


## Shizuku BatteryStats integration (GT 7T validation required)

The project now includes a Shizuku UserService bridge (AIDL) that runs the read-only command:

`dumpsys batterystats --charged --checkin`

The app parses these documented checkin sections:

- `uid`: UID-to-package mapping.
- `pwi,uid`: Android's estimated per-UID power in mAh.
- `st`: per-UID foreground, active and running state times.
- `pr`: per-process user/system/foreground CPU time.
- `pws`: reported battery capacity.
- `bt`: battery realtime window.

The dashboard shows estimated mAh and estimated battery percentage per hour where both reported capacity and time-window data are present. It also shows foreground time and background-running time separately.

**Foreground/background power split is intentionally not invented.** Android's checkin data gives per-UID estimated power, while foreground/background state times are separate measurements. It does not provide a trustworthy per-app mAh split between foreground and background. The app therefore displays total UID power attribution alongside separate activity durations. Shared UIDs are displayed as a combined package group because the system power value belongs to the UID, not an individual package.

### Shizuku setup

1. Start Shizuku (wireless debugging or root/Sui).
2. Open CellTrace and tap **Check / grant**.
3. Approve CellTrace in Shizuku. If the dashboard still says permission is not granted, tap **Check / grant** again to refresh status.
4. Tap **Read BatteryStats**.
5. The snapshot is read on demand; the app does not poll BatteryStats in the background.

This is a first device-independent parser pass. ColorOS firmware may omit or alter checkin sections. The dashboard shows warnings when expected data is missing. Test on the GT 7T and inspect the raw checkin output before treating results as validated device measurements.

The Shizuku API documentation notes that Shizuku executes with shell (ADB) or root identity and that shell permissions vary by Android release. UserService is the supported replacement for the deprecated `newProcess` API. Sources: https://github.com/RikkaApps/Shizuku-API and https://developer.android.com/tools/dumpsys.
